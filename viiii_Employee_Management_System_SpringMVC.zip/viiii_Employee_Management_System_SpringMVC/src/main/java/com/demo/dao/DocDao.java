package com.demo.dao;

import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.demo.model.Doc;



public class DocDao {
	
	private HibernateTemplate ht;



	public void setHt(HibernateTemplate ht) {
		this.ht = ht;
	}
	
	@Transactional
	public void saveEmployee(Doc e) {
		// TODO Auto-generated method stub
		
		ht.save(e);
	}
	
	@Transactional
	public List listEmployee() {
		// TODO Auto-generated method stub
		List<Doc> listall = ht.loadAll(Doc.class);
		return listall;
	}

	@Transactional
	public Doc listById(int id) {
		// TODO Auto-generated method stub
		
		Doc view = ht.get(Doc.class,id);
		return view;
	}

	@Transactional
	public void updateStudent(Doc s) {
		// TODO Auto-generated method stub
		
           ht.update(s);
		
	}

}
