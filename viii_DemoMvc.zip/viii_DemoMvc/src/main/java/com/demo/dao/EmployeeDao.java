package com.demo.dao;

import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.demo.model.Employee;



public class EmployeeDao {
	
	private HibernateTemplate htemplate;


	


	public HibernateTemplate getHtemplate() {
		return htemplate;
	}


	public void setHtemplate(HibernateTemplate htemplate) {
		this.htemplate = htemplate;
	}


	@Transactional
	public void saveEmployee(Employee e) {
		// TODO Auto-generated method stub
		
		htemplate.save(e);
	}


	@Transactional
	public List listEmployee() {
		// TODO Auto-generated method stub
		List<Employee> listall = htemplate.loadAll(Employee.class);
		return listall;
	}


	@Transactional
	public Employee listById(int id) {
		// TODO Auto-generated method stub
		Employee view = htemplate.get(Employee.class,id);
		return view;
	}


	@Transactional
	public void updateEmployee(Employee e) {
		// TODO Auto-generated method stub
		htemplate.update(e);
	}


	@Transactional
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		
		Employee view =new Employee();
		  // hibernate deletes objects by the primary key
		view.setEid(id);
		
		htemplate.getSessionFactory().getCurrentSession().delete(view);
	}

}
