package com.demo.dao;


import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.demo.model.RegistrationLogin;





public class RegistrationLoginDao {
	
	
	private HibernateTemplate ht;


	public void setHt(HibernateTemplate ht) {
		this.ht = ht;
	}


	@Transactional
	public void register(RegistrationLogin r) {
		// TODO Auto-generated method stub
		
		ht.save(r);
	}
	
	@Transactional
	public boolean login(String email, String password) {
		
		boolean success = false;

		 Criteria criteria = ht.getSessionFactory().getCurrentSession().createCriteria(RegistrationLogin.class);
		    criteria.add(Restrictions.eq("email", email));
		    criteria.add(Restrictions.eq("password", password));
		    RegistrationLogin rl = (RegistrationLogin) criteria.uniqueResult();
		    
		    if ( rl!=null ) {
	            success = true;
	        }

	        return success;

	  
	}



}
