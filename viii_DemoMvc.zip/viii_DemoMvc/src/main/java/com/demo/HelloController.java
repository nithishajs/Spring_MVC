package com.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.demo.dao.DocDao;
import com.demo.model.*;

@Controller
@RequestMapping
public class HelloController {
	
	@Autowired
	DocDao dc;
	
//	@GetMapping("/")
//	public String welcome() {
//		return "index";
//		
//	}
//	
//	@GetMapping("/home")
//	public String home(Model m) {
//	
//		return "home";
//	}
	
//	@PostMapping("/save")
//	public String save(@ModelAttribute("d") Doc d) {
//		dc.saveEmployee(d);
//		return "redirect:/index";
//	}
	
//	@GetMapping("/{id}")
//	public String lodeEditForm(@PathVariable(value="id") int id, Model m)
//	{
//		Doc emp=dc.listById(id);
//		
//		System.out.println(emp);
//		m.addAttribute("employee", emp);
//		
//		return "home";
//		
//	}
//	 /* It deletes record for the given id in URL and redirects to /viewemp */    
//    @RequestMapping(value="/update",method = RequestMethod.POST)    
//	public String update(@ModelAttribute("d") Doc d) {
//		dc.updateStudent(d);
//		return "redirect:/index";
//	}
	

}
