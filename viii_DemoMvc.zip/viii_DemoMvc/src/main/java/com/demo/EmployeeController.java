package com.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.demo.dao.EmployeeDao;
import com.demo.model.Employee;



@Controller
@RequestMapping
public class EmployeeController {
	
	
	@Autowired
	EmployeeDao d;
	
	@GetMapping("/addform")
	public String form(Model m) {
	
		return "redirect:/list";
		
	}
	
	@PostMapping("/add")
	public String add(@ModelAttribute("ed") Employee ed ) {
		d.saveEmployee(ed);
		return "redirect:/list";
		
	}
	
	

	@GetMapping("/list")
	public String list(Model m) {
		List <Employee> employee = d.listEmployee();
		System.out.println("----------------------"+employee.toString());
	    m.addAttribute("employee", employee);
		return "list_employee";
		
	}
	
	@GetMapping("/{id}")
	public String view(@PathVariable(value="id") int id, Model m) {
		Employee emp = d.listById(id);
		System.out.println(emp);
		m.addAttribute("viewEmp", emp);
		return "edit_employee";
		
	}
	
	@PostMapping("/update")
	public String edit(@ModelAttribute("U") Employee U ) {
		d.updateEmployee(U);
		return "redirect:/list";
		
	}
	
	@GetMapping("/delete/{id}")
	public String delete(@PathVariable int id ) {
		d.deleteEmployee(id);
		return "redirect:/list";
		
	}
	

}
