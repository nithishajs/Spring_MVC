package com.demo;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.demo.dao.RegistrationLoginDao;
import com.demo.model.RegistrationLogin;


@Controller
@RequestMapping
public class RegistrationLoginController {
	
	@Autowired
	RegistrationLoginDao dao;
	
	@PostMapping("/registered")
	public String register(@ModelAttribute("rl") RegistrationLogin rl ) {
		dao.register(rl);
		return "redirect:/login";
		
	}
	
	@PostMapping("/loged")
	public String login(HttpServletRequest req,Model m) {
		
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		
	System.out.println(email+" "+password);
		
		boolean dd = dao.login(email,password);
		
		if(dd) {
			return "redirect:/list";
			
		}else {
			return "redirect:/login";
			
		}
		

	}

}
